AisecCTF2024 -----------------------------

`Title`
Hidden Layers

`Description`
everything is useful, gather the pieces to find the pass.

`Tag`
> Forensics